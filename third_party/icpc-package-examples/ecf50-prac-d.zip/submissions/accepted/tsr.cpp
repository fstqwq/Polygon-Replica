#include <bits/stdc++.h>
#define MAXN 50
using namespace std;

int A[MAXN + 5][MAXN + 5];

int main() {
    int n; scanf("%d", &n);
    
    for (int i = 1; i <= n - 2; i++) for (int j = 1; j <= n; j++) A[i][j] = i;
    for (int j = 1; j <= n - 2; j++) for (int i = n - 1; i <= n; i++) A[i][j] = j + n - 2;
    A[n - 1][n - 1] = 2 * n - 3;
    A[n - 1][n] = 2 * n - 2;
    A[n][n - 1] = 2 * n - 1;
    A[n][n] = 2 * n;

    printf("Yes\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) printf("%d ", A[i][j]);
        printf("\n");
    }
    return 0;
}
