#include <bits/stdc++.h>
using namespace std;

//IAFDJKCEHMGLB
#define N 55
typedef long long LL;


// int find(int x){return x==fa[x]? x: fa[x]=find(fa[x]);}

// void merge(int x, int y){
//     x=find(x);
//     y=find(y);
//     fa[x]=y;
// }

int a[N][N];
int main()
{
    int T=1;
    //scanf("%d",&T);
    while (T--){
        int n;
        scanf("%d",&n);
        printf("Yes\n");
        a[1][1]=1;
        a[1][2]=2;
        a[2][1]=3;
        a[2][2]=4;
        int k=4;
        for (int i=3;i<=n;i++)
        {
            ++k;
            for (int j=1;j<i;j++)
                a[i][j]=k;
            ++k;
            for (int j=1;j<=i;j++)
                a[j][i]=k;
        }
        
        for (int i=1;i<=n;i++){
            for (int j=1;j<=n;j++){
                printf("%d%c",a[i][j],j==n? '\n':' ');
            }
        }
    }
    return 0;
}