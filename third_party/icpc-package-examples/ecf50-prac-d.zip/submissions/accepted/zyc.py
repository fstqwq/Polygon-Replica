n = int(input())
print("Yes")
for i in range(n):
    r = [(max(i, j) - (i == 0 and j == 1) << 1 | 1) + (i == j) for j in range(n)]
    print(' '.join(map(str, r)))