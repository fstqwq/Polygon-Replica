#include<bits/stdc++.h>
#define ll long long
using namespace std;

int a[100][100];

int main()
{
	ios_base::sync_with_stdio(false);
	
	int n;
	cin>>n;
	int m=2*n;
	for(int i=n;i>2;i--)
	{
		for(int j=1;j<=i;j++) a[i][j]=m;
		m--;
		for(int j=1;j<i;j++) a[j][i]=m;
		m--;
	}
	a[1][1]=1;
	a[1][2]=2;
	a[2][1]=3;
	a[2][2]=4;
	cout<<"Yes\n";
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) cout<<a[i][j]<<" \n"[j==n];
	
	return 0;
}
