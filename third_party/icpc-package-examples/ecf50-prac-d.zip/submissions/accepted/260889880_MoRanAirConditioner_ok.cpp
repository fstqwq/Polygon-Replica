// Skyqwq
#include <bits/stdc++.h>

#define pb push_back
#define fi first
#define se second
#define mp make_pair

using namespace std;

typedef pair<int, int> PII;
typedef long long LL;

template <typename T> bool chkMax(T &x, T y) { return (y > x) ? x = y, 1 : 0; }
template <typename T> bool chkMin(T &x, T y) { return (y < x) ? x = y, 1 : 0; }

template <typename T> void inline read(T &x) {
    int f = 1; x = 0; char s = getchar();
    while (s < '0' || s > '9') { if (s == '-') f = -1; s = getchar(); }
    while (s <= '9' && s >= '0') x = x * 10 + (s ^ 48), s = getchar();
    x *= f;
}

const int N = 55;

int n, a[N][N];

int main() {
   	read(n);
   	a[1][1] = 1, a[1][2] = 2;
   	a[2][1] = 3, a[2][2] = 4;
   	int c = 4;
   	for (int i = 3; i <= n; i++) {
   		a[i][i] = ++c; ++c;
   		for (int j = 1; j < i; j++) a[i][j] = a[j][i] = c;
   	}
   	puts("Yes");
   	for (int i = 1; i <= n; i++) {
   		for (int j = 1; j <= n; j++) {
   			printf("%d ", a[i][j]);
   		}
   		puts("");
   	}
    return 0;
}