#pragma GCC optimize("O3,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")

#include <bits/stdc++.h>
using namespace std;

#define ll long long
#define all(x) x.begin(), x.end()
#define pb push_back
#define mp make_pair
#define ps push
#define in insert
#define f first
#define s second
#define nl cout<<"\n"
#define ca(v) for(auto i:v) cout<<i<<" ";
#define cbit(x) __builtin_popcount(x)
#define gcd(a, b) __gcd(a, b)
#define lcm(a, b) (a*b/gcd(a, b))
const int xm[4] = {-1, 1, 0, 0};
const int ym[4] = {0, 0, -1, 1};
const int MOD = 1e9 + 7;
const int MAXN = 5e5 + 5;
const ll POW = 9973;

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);
    if (fopen("input.in", "r")) {
        freopen("input.in", "r", stdin);
        freopen("output.out", "w", stdout);
    }
    int n; cin>>n;
    cout<<"Yes\n";
    int ar[n][n];
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++) ar[i][j] = 1;
    }
    ar[n-1][0] = 2;
    ar[0][n-1] = 3;
    ar[n-1][n-1] = 4;

    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++) cout<<ar[i][j]<<" ";
        cout<<"\n";
    }
}

