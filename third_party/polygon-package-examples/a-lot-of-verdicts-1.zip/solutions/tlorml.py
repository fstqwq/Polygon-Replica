n = int(input())

a = []
while n % 2 != 1:
    a.extend([1, 2, 3, 4, 5])

print(n)