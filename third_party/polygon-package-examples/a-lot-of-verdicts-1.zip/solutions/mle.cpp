int *b;

int main() {
    
    while (1) {
        int *a = new int[1112];
        a[1] = 1;
        
        b = a;
    }
}