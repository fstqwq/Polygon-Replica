n = int(input())


while n % 2 != 1:
    pass
print(n)