#include<bits/stdc++.h>
#include "testlib.h"
 
using namespace std;

int main(int argc, char* argv[])
{
	registerValidation(argc, argv);
    // setTestCase();
	int n=inf.readInt(1, 50, "n");
	inf.readEoln();
	inf.readEof();
	return 0;
}
