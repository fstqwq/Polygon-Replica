echo [INFO]: Building problem 'sample-a'.
cd problems/sample-a
./doall.sh
cd -

echo [INFO]: Building problem 'sample-b'.
cd problems/sample-b
./doall.sh
cd -

echo [INFO]: Building problem 'sample-c'.
cd problems/sample-c
./doall.sh
cd -

echo [INFO]: Building problem 'sample-d'.
cd problems/sample-d
./doall.sh
cd -

echo [INFO]: Building english contest statement.
cd statements/english
./doall.sh
cd -

