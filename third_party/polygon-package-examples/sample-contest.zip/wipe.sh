echo [INFO]: Wiping problem 'sample-a'.
cd problems/sample-a
./wipe.sh
cd -

echo [INFO]: Wiping problem 'sample-b'.
cd problems/sample-b
./wipe.sh
cd -

echo [INFO]: Wiping problem 'sample-c'.
cd problems/sample-c
./wipe.sh
cd -

echo [INFO]: Wiping problem 'sample-d'.
cd problems/sample-d
./wipe.sh
cd -

echo [INFO]: Wiping english contest statement.
cd statements/english
./wipe.sh
cd -

