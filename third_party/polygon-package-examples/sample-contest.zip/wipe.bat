echo [INFO]: Wiping problem 'sample-a'.
pushd problems\sample-a
call wipe.bat
popd

echo [INFO]: Wiping problem 'sample-b'.
pushd problems\sample-b
call wipe.bat
popd

echo [INFO]: Wiping problem 'sample-c'.
pushd problems\sample-c
call wipe.bat
popd

echo [INFO]: Wiping problem 'sample-d'.
pushd problems\sample-d
call wipe.bat
popd

echo [INFO]: Wiping english contest statement.
pushd statements\english
call wipe.bat
popd

