echo [INFO]: Building problem 'sample-a'.
pushd problems\sample-a
call doall.bat
popd

echo [INFO]: Building problem 'sample-b'.
pushd problems\sample-b
call doall.bat
popd

echo [INFO]: Building problem 'sample-c'.
pushd problems\sample-c
call doall.bat
popd

echo [INFO]: Building problem 'sample-d'.
pushd problems\sample-d
call doall.bat
popd

echo [INFO]: Building english contest statement.
pushd statements\english
call doall.bat
popd

