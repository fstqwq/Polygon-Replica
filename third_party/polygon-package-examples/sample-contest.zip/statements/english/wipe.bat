pushd ..\..\problems\sample-a\statements\english
del /F /Q *.log
del /F /Q *.aux
del /F /Q *.dvi
del /F /Q *.pdf
del /F /Q *.ps
popd

pushd ..\..\problems\sample-b\statements\english
del /F /Q *.log
del /F /Q *.aux
del /F /Q *.dvi
del /F /Q *.pdf
del /F /Q *.ps
popd

pushd ..\..\problems\sample-c\statements\english
del /F /Q *.log
del /F /Q *.aux
del /F /Q *.dvi
del /F /Q *.pdf
del /F /Q *.ps
popd

pushd ..\..\problems\sample-d\statements\english
del /F /Q *.log
del /F /Q *.aux
del /F /Q *.dvi
del /F /Q *.pdf
del /F /Q *.ps
popd

del /F /Q *.log
del /F /Q *.aux
del /F /Q *.dvi
del /F /Q *.pdf
del /F /Q *.ps
