#include <iostream>

int main() { long long n; std::cin >> n; std::cout << 2 << '\n'; return 0; }
