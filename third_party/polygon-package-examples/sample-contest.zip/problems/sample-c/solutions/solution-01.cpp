#include <iostream>

int main() { long long n; std::cin >> n; std::cout << ((n % 2 + 2) % 2) << '\n'; return 0; }
