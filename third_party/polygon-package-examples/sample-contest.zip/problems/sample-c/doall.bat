rem   *** validation ***
call scripts\run-validator-tests.bat
call scripts\run-checker-tests.bat

rem    *** tests ***
md tests
call scripts\gen-input-via-stdout.bat "files\generator.exe 10 200 20 10 50 30 10 22 11 0" "tests\05" 5
call scripts\gen-input-via-stdout.bat "files\generator.exe 10 200 20 10 50 30 10 22 01 0" "tests\06" 6
call scripts\gen-input-via-stdout.bat "files\generator.exe 10 200 20 10 50 30 10 01 11 0" "tests\07" 7
call scripts\gen-input-via-stdout.bat "files\generator.exe 10 200 20 10 50 30 10 00 11 0" "tests\08" 8
call scripts\gen-input-via-stdout.bat "files\generator.exe 100 200 100 5 200 10 5 22 11 0" "tests\09" 9
call scripts\gen-input-via-stdout.bat "files\generator.exe 100 200 100 5 200 3 50 00 11 0" "tests\10" 10
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 1000000000 12 1000000000 23 4 22 11 0" "tests\11" 11
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 1000000000 5 1000000000 5 3 22 11 0" "tests\12" 12
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 1000000000 5 1000000000 5 3 00 11 0" "tests\13" 13
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 1000000000 5 1000000000 5 3 22 01 0" "tests\14" 14
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 10000 3 1000000000 20 5 22222 11111 0" "tests\15" 15
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 10000 3 1000000000 20 5 22222 11111 1" "tests\16" 16
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 3 1000000000 15 5 22222 11111 2" "tests\17" 17
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 5 1000000000 20 6 20202 00011 5" "tests\18" 18
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 5 1000000000 200 50 2222222222 0000000000 0" "tests\19" 19
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 5 1000000000 80 30 0101022222 0000000000 3" "tests\20" 20
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 5 1000000000 40 10 1111122222 0000000000 0" "tests\21" 21
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 5 1000000000 50 10 0101010122 0000000000 0" "tests\22" 22
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 5 1000000000 60 10 0002222111 0000000000 0" "tests\23" 23
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 5 1000000000 40 10 0011222222 0000000000 2" "tests\24" 24
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100000 5 1000000000 20 20 0100122222 0000000000 4" "tests\25" 25
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100 5 100 5 5 2222222222 1111111111 4" "tests\26" 26
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 100 5 100 5 5 2220000122 1111111111 2" "tests\27" 27
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 1000 10 20 3 2 0101022222 1111111111 0" "tests\28" 28
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 1000 30 20 2 2 0101022222 1111111111 0" "tests\29" 29
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 2000 30 20 2 2 0122222210 1111111111 0" "tests\30" 30
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 1000 10 2000 10 5 2222222222 1111111111 0" "tests\31" 31
call scripts\gen-input-via-stdout.bat "files\generator.exe 2000 5000 1000 20 2000 40 7 2222222222 1111111111 0" "tests\32" 32
call scripts\gen-input-via-stdout.bat "files\generator.exe 1000 5000 3000 28 30000 40 6 0101012222 1111111111 0" "tests\33" 33
call scripts\gen-input-via-stdout.bat "files\generator.exe 1000 5000 5000 10 50000 40 10 0000011111 1111111111 0" "tests\34" 34
call scripts\gen-input-via-stdout.bat "files\generator.exe 1000 5000 5000 10 50000 40 10 0000022222 1111111111 0" "tests\35" 35
call scripts\gen-input-via-stdout.bat "files\generator.exe 1000 5000 5000 10 50000 40 10 0000022222 1111111111 4" "tests\36" 36
call scripts\gen-input-via-stdout.bat "files\generator.exe 30 5000 10000 900 100000 1600 200 0102222101 1111111111 0" "tests\37" 37
call scripts\gen-input-via-stdout.bat "files\generator.exe 30 5000 10000 300 100000 600 400 0101010101 1111111111 0" "tests\38" 38
call scripts\gen-input-via-stdout.bat "files\generator.exe 30 5000 10000 500 100000 800 200 0101010101 1111111111 0" "tests\39" 39
call scripts\gen-input-via-stdout.bat "files\generator.exe 30 5000 10000 500 100000 800 200 2222222222 1111111111 3" "tests\40" 40
call scripts\gen-input-via-stdout.bat "files\generator.exe 30 5000 10000 500 100000 800 200 2222222222 0000000000 3" "tests\41" 41
call scripts\gen-input-via-stdout.bat "files\generator.exe 30 5000 10000 500 100000 1000 10 2222222222 0000000000 2" "tests\42" 42
call scripts\gen-input-via-stdout.bat "files\generator.exe 30 5000 10000 500 100000 10 2000 2000221112 0000000000 2" "tests\43" 43
call scripts\gen-input-via-stdout.bat "files\generator.exe 40 5000 10000 500 6000 10 2000 2000221112 0000000000 3" "tests\44" 44
call scripts\gen-answer.bat tests\01 tests\01.a "tests" ""
call scripts\gen-answer.bat tests\02 tests\02.a "tests" ""
call scripts\gen-answer.bat tests\03 tests\03.a "tests" ""
call scripts\gen-answer.bat tests\04 tests\04.a "tests" ""
call scripts\gen-answer.bat tests\05 tests\05.a "tests" ""
call scripts\gen-answer.bat tests\06 tests\06.a "tests" ""
call scripts\gen-answer.bat tests\07 tests\07.a "tests" ""
call scripts\gen-answer.bat tests\08 tests\08.a "tests" ""
call scripts\gen-answer.bat tests\09 tests\09.a "tests" ""
call scripts\gen-answer.bat tests\10 tests\10.a "tests" ""
call scripts\gen-answer.bat tests\11 tests\11.a "tests" ""
call scripts\gen-answer.bat tests\12 tests\12.a "tests" ""
call scripts\gen-answer.bat tests\13 tests\13.a "tests" ""
call scripts\gen-answer.bat tests\14 tests\14.a "tests" ""
call scripts\gen-answer.bat tests\15 tests\15.a "tests" ""
call scripts\gen-answer.bat tests\16 tests\16.a "tests" ""
call scripts\gen-answer.bat tests\17 tests\17.a "tests" ""
call scripts\gen-answer.bat tests\18 tests\18.a "tests" ""
call scripts\gen-answer.bat tests\19 tests\19.a "tests" ""
call scripts\gen-answer.bat tests\20 tests\20.a "tests" ""
call scripts\gen-answer.bat tests\21 tests\21.a "tests" ""
call scripts\gen-answer.bat tests\22 tests\22.a "tests" ""
call scripts\gen-answer.bat tests\23 tests\23.a "tests" ""
call scripts\gen-answer.bat tests\24 tests\24.a "tests" ""
call scripts\gen-answer.bat tests\25 tests\25.a "tests" ""
call scripts\gen-answer.bat tests\26 tests\26.a "tests" ""
call scripts\gen-answer.bat tests\27 tests\27.a "tests" ""
call scripts\gen-answer.bat tests\28 tests\28.a "tests" ""
call scripts\gen-answer.bat tests\29 tests\29.a "tests" ""
call scripts\gen-answer.bat tests\30 tests\30.a "tests" ""
call scripts\gen-answer.bat tests\31 tests\31.a "tests" ""
call scripts\gen-answer.bat tests\32 tests\32.a "tests" ""
call scripts\gen-answer.bat tests\33 tests\33.a "tests" ""
call scripts\gen-answer.bat tests\34 tests\34.a "tests" ""
call scripts\gen-answer.bat tests\35 tests\35.a "tests" ""
call scripts\gen-answer.bat tests\36 tests\36.a "tests" ""
call scripts\gen-answer.bat tests\37 tests\37.a "tests" ""
call scripts\gen-answer.bat tests\38 tests\38.a "tests" ""
call scripts\gen-answer.bat tests\39 tests\39.a "tests" ""
call scripts\gen-answer.bat tests\40 tests\40.a "tests" ""
call scripts\gen-answer.bat tests\41 tests\41.a "tests" ""
call scripts\gen-answer.bat tests\42 tests\42.a "tests" ""
call scripts\gen-answer.bat tests\43 tests\43.a "tests" ""
call scripts\gen-answer.bat tests\44 tests\44.a "tests" ""

