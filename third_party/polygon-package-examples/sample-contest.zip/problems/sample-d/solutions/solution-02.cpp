#include <iostream>

int main() { long long n; std::cin >> n; std::cout << 1 << ' ' << n - 1 << '\n'; return 0; }
