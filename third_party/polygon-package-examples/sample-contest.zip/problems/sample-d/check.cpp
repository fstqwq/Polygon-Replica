#include "testlib.h"
#include <cstdlib>
#include <string>

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    const long long n = inf.readLong();
    const std::string first = ouf.readToken();
    if (first == "CRASH") std::abort();
    long long a = 0;
    try { a = std::stoll(first); } catch (...) { quitf(_wa, "first token is not an integer"); }
    const long long b = ouf.readLong();
    if (a <= 0 || b <= 0) quitf(_wa, "both parts must be positive");
    if (a + b != n) quitf(_wa, "parts do not sum to n");
    quitf(_ok, "valid split");
}
