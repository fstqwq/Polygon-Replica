import sys


def main() -> None:
    del sys.argv
    print(7)


if __name__ == "__main__":
    main()
