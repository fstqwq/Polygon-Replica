"""The optional local testing tool is not included in this sample package."""

raise SystemExit("No local testing tool is provided.")
