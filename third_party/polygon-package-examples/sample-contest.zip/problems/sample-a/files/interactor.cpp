#include "testlib.h"
#include <iostream>

int main(int argc, char* argv[]) {
    registerInteraction(argc, argv);
    const int expected = inf.readInt();
    tout << expected << std::endl;
    const int actual = ouf.readInt();
    if (actual == expected) quitf(_ok, "echoed value");
    quitf(_wa, "expected %d, found %d", expected, actual);
}
