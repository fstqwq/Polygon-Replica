#include "testlib.h"
#include <cstdlib>
#include <string>

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    const std::string token = ouf.readToken();
    if (token == "CRASH") {
        std::abort();
    }
    const int expected = ans.readInt();
    const int actual = stringToLongLong(ouf.name, token.c_str());
    if (actual == expected) {
        quitf(_ok, "value matches");
    }
    quitf(_wa, "expected %d, found %d", expected, actual);
}
