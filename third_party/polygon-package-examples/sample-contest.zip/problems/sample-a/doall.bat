rem   *** validation ***
call scripts\run-validator-tests.bat
call scripts\run-checker-tests.bat

rem    *** tests ***
md tests
call scripts\gen-input-via-stdout.bat "py -3 files\generator.py 1 123" "tests\01" 1
call scripts\gen-input-via-stdout.bat "py -3 files\generator.py 1 321" "tests\02" 2
call scripts\gen-input-via-stdout.bat "py -3 files\generator.py 100 123" "tests\03" 3
call scripts\gen-input-via-stdout.bat "py -3 files\generator.py 100 321" "tests\04" 4
call scripts\gen-input-via-stdout.bat "py -3 files\generator.py 100 123456789" "tests\05" 5
call scripts\gen-input-via-stdout.bat "py -3 files\generator.py 100 987654321" "tests\06" 6
call scripts\gen-answer.bat tests\01 tests\01.a "tests" ""
call scripts\gen-answer.bat tests\02 tests\02.a "tests" ""
call scripts\gen-answer.bat tests\03 tests\03.a "tests" ""
call scripts\gen-answer.bat tests\04 tests\04.a "tests" ""
call scripts\gen-answer.bat tests\05 tests\05.a "tests" ""
call scripts\gen-answer.bat tests\06 tests\06.a "tests" ""

