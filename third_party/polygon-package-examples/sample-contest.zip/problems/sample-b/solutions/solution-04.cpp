int main() { for (;;) {} }
