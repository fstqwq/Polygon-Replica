#include "testlib.h"

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    inf.readInt(-100000, 100000, "a");
    inf.readSpace();
    inf.readInt(-100000, 100000, "b");
    inf.readEoln();
    inf.readEof();
}
