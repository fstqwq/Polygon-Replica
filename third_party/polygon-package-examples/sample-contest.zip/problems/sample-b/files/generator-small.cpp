#include "testlib.h"

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);
    println("2 3");
}
