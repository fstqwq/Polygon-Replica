#include "testlib.h"
#include <iostream>

int main(int argc, char* argv[]) {
    registerInteraction(argc, argv);
    const int a = inf.readInt();
    const int b = inf.readInt();
    tout << a << ' ' << b << std::endl;
    const int actual = ouf.readInt();
    if (actual == a + b) quitf(_ok, "sum is correct");
    quitf(_wa, "expected %d, found %d", a + b, actual);
}
