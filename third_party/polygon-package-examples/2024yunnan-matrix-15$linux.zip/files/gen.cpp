#include"testlib.h"
#include<bits/stdc++.h>
#define ll long long
using namespace std;


int main(int argc,char* argv[])
{
    registerGen(argc,argv,1);
	
	int n = atoi(argv[1]);
	cout<<n<<endl;
	
	return 0;
}