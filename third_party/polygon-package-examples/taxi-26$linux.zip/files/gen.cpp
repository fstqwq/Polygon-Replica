#include"testlib.h"
#include<bits/stdc++.h>
#define ll long long
using namespace std;

int main(int argc,char* argv[])
{
	registerGen(argc,argv,1);
	
	//全随机， 钦定AB打车， T>=sigma bi， pi有偏随机， 
	int n= atoi(argv[1]);
	int T= atoi(argv[2]);
	int a= atoi(argv[3]);
	int b= atoi(argv[4]);
	int c= atoi(argv[5]);
	int d= atoi(argv[6]);
	int e= atoi(argv[7]);
	
	char *str = argv[8];
	//0/1 钦定
	//2 rand,pi
	char *str2= argv[9];
	//0/1  00
	int sn=strlen(str),len=n/sn;
	
	int p= atoi(argv[10]);
	
	cout<<n<<' '<<T<<endl;
	for(int i=0;i<sn;i++)
	{
		for(int j=1;j<=len;j++)
		{
			if(str2[i]=='0') cout<<"0 0 ";
			else
			{
			    int ra=rnd.next(0,a),rb=rnd.next(0,b);
			    cout<<ra<<' '<<rb<<' ';
			}
			int rc=rnd.next(0,c),rd=rnd.next(0,d),re=rnd.next(0,e);
			cout<<rc<<' '<<rd<<' '<<re<<' ';
			
			if(str[i]=='0') cout<<0<<endl;
			else if(str[i]=='1') cout<<100<<endl;
			else cout<<rnd.wnext(101,p)<<endl;
		}
	}
	
	return 0;
}