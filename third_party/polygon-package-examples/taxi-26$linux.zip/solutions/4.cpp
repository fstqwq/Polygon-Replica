#include<cstdio>
#include<algorithm>
#include<vector>
#include<cmath>
#include<cstdlib>
#include<set>
#include<assert.h>
#include<cstring>
#include<map>
#define pii pair<int,int>
#define pb push_back
#define rep(i,j,k) for(int i=(int)(j);i<=(int)(k);i++)
#define per(i,j,k) for(int i=(int)(j);i>=(int)(k);i--)
using namespace std;
typedef long long LL;
const int N=2005;
double dp[2][10005][2][2];
int n,T;
int a[N],b[N];
int c[N],d[N];
int e[N];double p[N];
const double inf=1e20;
int main(){
  scanf("%d%d",&n,&T);
  rep(i,1,n){
    scanf("%d%d%d%d%d",&a[i],&b[i],&c[i],&d[i],&e[i]);
    scanf("%lf",&p[i]);p[i]/=100.0;
  }
  int now=0;
  rep(i,0,T)rep(j,0,1)rep(k,0,1)dp[now][i][j][k]=0;
  per(i,n,1){
    rep(j,0,T)rep(v1,0,1)rep(v2,0,1){
      double ma=-inf;
      if(j+b[i]<=T){
        double value=0;
        if(p[i]>0.0001)value+=p[i]*dp[now][j+b[i]][v1|1][v2];
        if(p[i]<0.9999)value+=(1.0-p[i])*dp[now][j+b[i]][v1][v2|1];
        ma=max(value+a[i],ma);
      }
      if(j+d[i]+e[i]*v1*v2<=T){
        if(v1&&v2){
          ma=max(ma,c[i]+dp[now][j+d[i]+e[i]][0][0]);
        }
        else{
          double value=0;
          if(p[i]>0.0001)value+=p[i]*dp[now][j+d[i]][v1|1][v2];
          if(p[i]<0.9999)value+=(1.0-p[i])*dp[now][j+d[i]][v1][v2|1];
          ma=max(ma,value+c[i]);
        }
      }
      dp[now^1][j][v1][v2]=ma;
    }
    now^=1;
  }
  if(dp[now][0][0][0]>=0)printf("%.10lf\n",dp[now][0][0][0]);
  else printf("-1\n");
  return 0;
}



