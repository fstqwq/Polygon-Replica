#include <bits/stdc++.h>

using namespace std;

const double INF = 1e18;

int main() {
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n, t;
    cin >> n >> t;
    vector<int> a(n), b(n), c(n), d(n), e(n);
    vector<double> p(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i] >> b[i] >> c[i] >> d[i] >> e[i] >> p[i];
        p[i] /= 100;
    }
    vector<array<double, 4>> dp(t + 1);
    for (int i = n - 1; ~i; --i) {
        vector<array<double, 4>> new_dp(t + 1, {-INF, -INF, -INF, -INF});
        for (int j = 0; j <= t; ++j) {
            for (int s = 0; s < 4; ++s) {
                if (j + b[i] <= t) {
                    new_dp[j][s] = max(new_dp[j][s], p[i] * dp[j + b[i]][s | 1] +
                                                         (1 - p[i]) * dp[j + b[i]][s | 2] + a[i]);
                }
                if (j + d[i] + e[i] * (s == 3) <= t) {
                    if (s == 3) {
                        new_dp[j][s] = max(new_dp[j][s], dp[j + d[i] + e[i]][0] + c[i]);
                    } else {
                        new_dp[j][s] =
                            max(new_dp[j][s], p[i] * dp[j + d[i]][s | 1] +
                                                  (1 - p[i]) * dp[j + d[i]][s | 2] + c[i]);
                    }
                }
            }
        }
        swap(dp, new_dp);
    }
    if (dp[0][0] >= 0) {
        cout << fixed << setprecision(9) << dp[0][0] << "\n";
    } else {
        cout << -1 << "\n";
    }
    return 0;
}
