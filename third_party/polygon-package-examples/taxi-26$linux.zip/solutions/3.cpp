#include <iostream>
#include <iomanip>
#include <vector>
#include <cstdlib>
#include <cstring>
using namespace std;

const int N = 2005;
const int M = 10005;

int n, m, a[N], b[N], c[N], d[N], e[N], p[N];
int min_budget[N][4]; // 1: only A, 2: only B
long double dp[2][M][4];
int main() {
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        cin >> a[i] >> b[i] >> c[i] >> d[i] >> e[i] >> p[i];
    }
    memset(min_budget[n + 1], 0, sizeof(min_budget[n + 1]));
    for (int i = n; i; i--) {
        for (int mask = 0; mask < 4; mask++) {
            int canteen = b[i];
            int restaurant = d[i];
            if (mask == 3) {
                canteen += min_budget[i + 1][3];
                restaurant += min_budget[i + 1][0] + e[i];
            } else if (mask == 2) {
                int tmp;
                if (p[i]) tmp = min_budget[i + 1][3];
                else tmp = min_budget[i + 1][2];
                restaurant += tmp, canteen += tmp;
            } else if (mask == 1) {
                int tmp;
                if (p[i] < 100) tmp = min_budget[i + 1][3];
                else tmp = min_budget[i + 1][1];
                restaurant += tmp, canteen += tmp;
            } else {
                int tmp;
                if (!p[i]) tmp = min_budget[i + 1][2];
                else if (p[i] == 100) tmp = min_budget[i + 1][1];
                else tmp = max(min_budget[i + 1][1], min_budget[i + 1][2]);
                restaurant += tmp, canteen += tmp;
            }
            min_budget[i][mask] = min(restaurant, canteen);
        }
    }
    if (min_budget[1][0] > m) {cout << -1 << endl; return 0;}

    auto clr = [](int cur) {
        for (int i = 0; i <= m; i++)
            for (int mask = 0; mask < 4; mask++)
                dp[cur][i][mask] = -1e50;
    };

    int cur = 0;
    for (int i = n; i ; i--) {
        int pre = cur;
        cur ^= 1;
        clr(cur);

        for (int mask = 0; mask < 4; mask++) {
            for (int t = min_budget[i][mask]; t <= m; t++) {
                long double canteen = -1e50, restaurant = -1e50;
                if (t >= b[i]) canteen = dp[pre][t - b[i]][mask | 1] * p[i] / 100.L + dp[pre][t - b[i]][mask | 2] * (100 - p[i]) / 100.L + a[i];
                if (mask == 3) {
                    if (t >= d[i] + e[i]) restaurant = dp[pre][t - d[i] - e[i]][0] + c[i];
                } else {
                    if (t >= d[i]) restaurant = dp[pre][t - d[i]][mask | 1] * p[i] / 100.L + dp[pre][t - d[i]][mask | 2] * (100 - p[i]) / 100.L + c[i];
                }
                dp[cur][t][mask] = max(canteen, restaurant);
            }
        }
    }

    cout << setiosflags(ios::fixed) << setprecision(10) << dp[cur][m][0] << endl;
    return 0;
}