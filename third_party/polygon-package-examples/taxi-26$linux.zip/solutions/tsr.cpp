#include <bits/stdc++.h>
#define MAXN 2000
#define MAXM ((int) 1e4)
using namespace std;
typedef long double db;

int n, m, A[MAXN + 5][6];
db f[2][MAXM + 5][4];

void update(db &a, db b) { a = max(a, b); }

int main() {
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++) for (int j = 0; j < 6; j++) scanf("%d", &A[i][j]);

    for (int i = n - 1; i >= 0; i--) {
        for (int j = 0; j <= m; j++) for (int k = 0; k < 4; k++) f[i & 1][j][k] = -1e300;
        for (int j = 0; j <= m; j++) for (int k = 0; k < 4; k++) {
            if (j >= A[i + 1][1]) {
                double t = f[i & 1 ^ 1][j - A[i + 1][1]][k | 1] * A[i + 1][5] / 100;
                t += f[i & 1 ^ 1][j - A[i + 1][1]][k | 2] * (100 - A[i + 1][5]) / 100;
                t += A[i + 1][0];
                update(f[i & 1][j][k], t);
            }
            if (j >= A[i + 1][3] && k != 3) {
                double t = f[i & 1 ^ 1][j - A[i + 1][3]][k | 1] * A[i + 1][5] / 100;
                t += f[i & 1 ^ 1][j - A[i + 1][3]][k | 2] * (100 - A[i + 1][5]) / 100;
                t += A[i + 1][2];
                update(f[i & 1][j][k], t);
            }
            if (j >= A[i + 1][3] + A[i + 1][4] && k == 3) {
                update(f[i & 1][j][k], f[i & 1 ^ 1][j - A[i + 1][3] - A[i + 1][4]][0] + A[i + 1][2]);
            }
        }
    }

    if (f[0][m][0] >= 0) printf("%.12Lf\n", f[0][m][0]);
    else printf("-1\n");
    return 0;
}
