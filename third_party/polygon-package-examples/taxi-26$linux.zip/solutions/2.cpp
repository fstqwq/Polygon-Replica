#include <bits/stdc++.h>

using namespace std;

int n, T;
using flt = long double;
flt dp[2][10010][4];

int main() {
    const flt INF = 1e50;
    ios::sync_with_stdio(false);
    cin >> n >> T;
    vector<int> a(n), b(n), c(n), d(n), e(n);
    vector<flt> pa(n), pb(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i] >> b[i] >> c[i] >> d[i] >> e[i] >> pa[i];
        pa[i] /= 100.0;
        pb[i] = 1 - pa[i];
    }
    for (int i = n - 1; i >= 0; i--) {
        int now = i & 1;
        int nxt = now ^ 1;
        for (int j = 0; j <= T; j++) {
            for (int k = 0; k < 4; k++) {
                flt ret = -INF;
                if (j - b[i] >= 0) {
                    ret = max(ret, a[i] + pa[i] * dp[nxt][j - b[i]][k | 2] + pb[i] * dp[nxt][j - b[i]][k | 1]);
                }
                if (j - d[i] >= 0) {
                    if (k == 3) {
                        if (j - d[i] - e[i] >= 0) {
                            ret = max(ret, c[i] + dp[nxt][j - d[i] - e[i]][0]);
                        }
                    } else {
                        ret = max(ret, c[i] + pa[i] * dp[nxt][j - d[i]][k | 2] + pb[i] * dp[nxt][j - d[i]][k | 1]);
                    }
                }
                if (ret < 0) ret = -INF;
                dp[now][j][k] = ret;
            }
        }
    }
    flt ans = -INF;
    for (int i = 0; i <= T; i++) {
        ans = max(ans, dp[0][i][0]);
    }
    if (ans < 0) {
        cout << "-1\n";
    } else {
        cout << fixed << setprecision(12) << ans << '\n';
    }
}