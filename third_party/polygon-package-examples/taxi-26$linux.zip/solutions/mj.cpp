#include <bits/stdc++.h>
#include <iomanip>

using namespace std;

constexpr double inf = 1E16;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);

    int n, T;
    cin >> n >> T;

    vector<int> a(n), b(n), c(n), d(n), e(n), P(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i] >> b[i] >> c[i] >> d[i] >> e[i] >> P[i];
    }

    vector<array<double, 4>> f(T + 1);

    for (int i = n - 1; i >= 0; i--) {
        vector<array<double, 4>> nf(T + 1, {-inf, -inf, -inf, -inf});

        for (int j = 0; j <= T; j++) {
            for (int k = 0; k < 4; k++) {
                if (j >= b[i]) {
                    nf[j][k] = max(nf[j][k], a[i] + P[i] * f[j - b[i]][k | 1] / 100 + (100 - P[i]) * f[j - b[i]][k | 2] / 100);
                }
                if (k == 3 && j >= e[i] + d[i]) {
                    nf[j][k] = max(nf[j][k], c[i] + f[j - e[i] - d[i]][0]);
                }
				if (k < 3 && j >= d[i]) {
                    nf[j][k] = max(nf[j][k], c[i] + P[i] * f[j - d[i]][k | 1] / 100 + (100 - P[i]) * f[j - d[i]][k | 2] / 100);
				}
                if (nf[j][k] < 0) {
                    nf[j][k] = -inf;
                }
            }
        }
        swap(f, nf);

		// for (int j = 0; j <= T; j++) {
		// 	cerr << j << ": [";
		// 	for (int k = 0; k < 4; k++) {
		// 		cerr << f[j][k] << " ]"[k == 3];
		// 	}
		// 	cerr << '\n';
		// }
    }

    if (f[T][0] < 0) {
        cout << "-1\n";
        return 0;
    }

    cout << fixed << setprecision(15) << f[T][0] << '\n';

    return 0;
}