#include<bits/stdc++.h>
#define ll long long
using namespace std;

inline void up(double &a,const double &b){ if(a<b) a=b; }
const int maxn = 2050;
const int maxt = 10050;
const double inf = 1e18;

int n,T;
vector<double>ai,bi,ci,di,ei;
vector<double>pi,qi;

double f[2][maxt][4];

int main()
{
	ios_base::sync_with_stdio(false);
	
	cin>>n>>T;
	ai.resize(n+10),bi.resize(n+10),ci.resize(n+10),di.resize(n+10),ei.resize(n+10);
	pi.resize(n+10),qi.resize(n+10);
	
	for(int i=1;i<=n;i++)
	{
		cin>>ai[i]>>bi[i]>>ci[i]>>di[i]>>ei[i];
		int Pi; cin>>Pi;
		pi[i]= Pi/100.0;
		qi[i]= 1-pi[i];
	}
	
	for(int i=0;i<2;i++) for(int j=0;j<=T;j++) for(int s=0;s<4;s++) f[i][j][s]=-inf;
	
	int now=0;
	for(int t=0;t<=T;t++) for(int s=0;s<4;s++) f[now][t][s]=0.0;
	
	for(int i=n;i>=1;i--)
	{
		int a=ai[i], c=ci[i];
		int b=bi[i],d=di[i],e=ei[i];
		double p=pi[i],q=qi[i];
		
		now=!now;
		for(int t=0;t<=T;t++)
		{
			for(int s=0;s<4;s++)
			{
				double &temp= f[now][t][s];
				if(t+b<=T)
				{
					up(temp, a+ p*f[!now][t+b][s|1]+q*f[!now][t+b][s|2]);
				}
				if(t+d<=T)
				{
					if(t+d+e<=T)
					{
						up(temp, c+ f[!now][t+d+e][0]);
					}
					if(s!=3)
					{
						up(temp, c+ p*f[!now][t+d][s|1]+q*f[!now][t+d][s|2]);
					}
				}
			}
		}
		
		for(int t=0;t<=T;t++) for(int s=0;s<4;s++) f[!now][t][s]=-inf;
	}
	double ans=-inf;
	for(int t=0;t<=T;t++) for(int s=0;s<4;s++)
		up(ans,f[now][t][s]);
	
	if(ans<0) cout<<-1<<endl;
	else cout<<fixed<<setprecision(12)<<ans<<endl;
	
	return 0;
}
