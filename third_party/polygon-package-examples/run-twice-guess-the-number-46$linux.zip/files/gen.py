import sys
print("%d %s %s" % (1, sys.argv[1], sys.argv[2]))