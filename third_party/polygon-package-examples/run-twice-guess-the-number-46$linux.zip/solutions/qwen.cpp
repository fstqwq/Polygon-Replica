#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>

using namespace std;

string reverseString(const string& s) {
    return string(s.rbegin(), s.rend());
}

string intToBinary(int num) {
    string binary = "";
    for (int i = 7; i >= 0; i--) {
        if (num & (1 << i)) {
            binary += '1';
        } else {
            binary += '0';
        }
    }
    return binary;
}

int binaryToInt(const string& binary) {
    int result = 0;
    for (int i = 0; i < 8; i++) {
        if (binary[i] == '1') {
            result |= (1 << (7 - i));
        }
    }
    return result;
}

int main() {
    int r, n;
    cin >> r >> n;
    
    if (r == 1) {
        // Create encoding map
        unordered_map<int, string> numberToCode;
        vector<bool> used(256, false);
        
        int code = 0;
        for (int num = 0; num <= 100; num++) {
            while (code < 256) {
                string binary = intToBinary(code);
                string reversed = reverseString(binary);
                int reversedCode = binaryToInt(reversed);
                
                if (!used[code] && !used[reversedCode]) {
                    numberToCode[num] = binary;
                    used[code] = true;
                    used[reversedCode] = true;
                    break;
                }
                code++;
            }
        }
        
        // Process each secret number
        for (int i = 0; i < n; i++) {
            int secret = -1;
            
            // Ask about 0 to 99 (100 queries max)
            for (int guess = 0; guess <= 99; guess++) {
                cout << "? " << guess << endl;
                cout.flush();
                
                int response;
                cin >> response;
                
                if (response == 1) {
                    secret = guess;
                    break;
                }
            }
            
            // If not found in 0-99, it must be 100
            if (secret == -1) {
                secret = 100;
            }
            
            cout << "! " << numberToCode[secret] << endl;
            cout.flush();
        }
    } else {
        // Second run: decode the notes
        unordered_map<string, int> codeToNumber;
        vector<bool> used(256, false);
        
        int code = 0;
        for (int num = 0; num <= 100; num++) {
            while (code < 256) {
                string binary = intToBinary(code);
                string reversed = reverseString(binary);
                int reversedCode = binaryToInt(reversed);
                
                if (!used[code] && !used[reversedCode]) {
                    codeToNumber[binary] = num;
                    codeToNumber[reversed] = num;
                    used[code] = true;
                    used[reversedCode] = true;
                    break;
                }
                code++;
            }
        }
        
        // Process each note
        for (int i = 0; i < n; i++) {
            string note;
            cin >> note;
            cout << codeToNumber[note] << endl;
            cout.flush();
        }
    }
    
    return 0;
}
