#include <bits/stdc++.h>
using namespace std;
const int MIN=0;
const int MAX=100;
std::map<std::string, int> mp;
std::vector<std::string> vec;
int FirstRun()
{
    for(int i=MIN; i<MAX; i++)
    {
        printf("? %d\n",i);
        fflush(stdout);
        int res;
        scanf("%d",&res);
        if(res)
        {
            printf("! %s\n",vec[i-MIN].c_str());
            fflush(stdout);
            return 0;
        }
    }
    printf("! %s\n",vec[MAX-MIN].c_str());
    fflush(stdout);
    return 0;
}
int SecondRun()
{
    char s[15];
    scanf("%s",s);
    std::string bits = s, reversed_bits = bits;
    std::reverse(reversed_bits.begin(), reversed_bits.end());
    int v=mp[std::min(bits, reversed_bits)];
    printf("%d\n",v);
    fflush(stdout);
    return 0;
}
int main()
{
    int total = 0;
    for (int i = 0; i < 256; i++)
    {
        std::string bits = std::bitset<8>(i).to_string();
        std::string reversed_bits = bits;
        std::reverse(reversed_bits.begin(), reversed_bits.end());
        std::string key = std::min(bits, reversed_bits);
        if (mp.find(key) == mp.end())
        {
            vec.push_back(key);
            mp[key] = total++;
        }
    }
    int op,T;
    scanf("%d%d",&op,&T);
    while(T--)
    {
        if(op==1)FirstRun();
        else SecondRun();
    }
    return 0;
}
