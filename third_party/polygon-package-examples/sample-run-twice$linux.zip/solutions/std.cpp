#include <iostream>

int main() {
    int phase = 0;
    int count = 0;
    if (!(std::cin >> phase >> count)) {
        return 0;
    }
    for (int index = 0; index < count; ++index) {
        int value = 0;
        std::cin >> value;
        std::cout << value << std::endl;
    }
    return 0;
}
