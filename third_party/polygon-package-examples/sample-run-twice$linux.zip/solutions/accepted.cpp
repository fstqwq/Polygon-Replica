#include <cstdio>

int main() {
    int phase = 0;
    int count = 0;
    if (std::scanf("%d%d", &phase, &count) != 2) {
        return 0;
    }
    while (count-- > 0) {
        int value = 0;
        std::scanf("%d", &value);
        std::printf("%d\n", value);
        std::fflush(stdout);
    }
    return 0;
}
