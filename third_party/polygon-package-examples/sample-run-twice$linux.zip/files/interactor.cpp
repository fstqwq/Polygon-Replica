#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

static int fixture_value(int seed, int index) {
    return (seed + index * 17) % 101;
}

int main(int argc, char* argv[]) {
    registerInteraction(argc, argv);
    const int phase = inf.readInt(1, 2, "phase");
    const int count = inf.readInt(1, 100, "count");

    cout << phase << " " << count << endl;

    if (phase == 1) {
        const int seed = inf.readInt(1, 1000000000, "seed");
#ifdef DOMJUDGE
        tout.open(make_new_file_in_a_dir(argv[3], "nextpass.in"), ios_base::out);
#endif
        tout << 2 << " " << count << "\n";
        for (int index = 0; index < count; ++index) {
            const int value = fixture_value(seed, index);
            cout << value << endl;
            const int echoed = ouf.readInt(0, 100, "echoed");
            if (echoed != value) {
                quitf(_wa, "expected %d, found %d", value, echoed);
            }
            tout << value << "\n";
        }
        quitf(_ok, "synthetic first pass accepted");
    }

    for (int index = 0; index < count; ++index) {
        const int value = inf.readInt(0, 100, "value");
        cout << value << endl;
        const int echoed = ouf.readInt(0, 100, "echoed");
        if (echoed != value) {
            quitf(_wa, "expected %d, found %d", value, echoed);
        }
    }
    quitf(_ok, "synthetic second pass accepted");
}
