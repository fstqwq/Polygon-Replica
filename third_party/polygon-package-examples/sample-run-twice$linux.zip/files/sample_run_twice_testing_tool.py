#!/usr/bin/env python3
"""Dummy testing tool included only as a package-import fixture."""

print("This testing tool is intentionally not implemented.")
