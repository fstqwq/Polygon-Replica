#!/usr/bin/env python3
"""Synthetic generator retained to exercise Polygon package structure."""

import sys


count = int(sys.argv[1])
seed = int(sys.argv[2])
print(1, count, seed)
