#include "testlib.h"

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    inf.readInt(1, 1, "phase");
    inf.readSpace();
    inf.readInt(1, 100, "count");
    inf.readSpace();
    inf.readInt(1, 1000000000, "seed");
    inf.readEoln();
    inf.readEof();
}
